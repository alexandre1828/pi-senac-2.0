// Navegação entre seções
function showSection(sectionId) {
    // Remove active class from all nav items and sections
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    document.querySelectorAll('.section-content').forEach(section => section.classList.remove('active'));
    
    // Add active class to clicked nav item and corresponding section
    event.target.classList.add('active');
    document.getElementById(sectionId).classList.add('active');
}

// Event listeners para navegação
document.addEventListener('DOMContentLoaded', function() {
    // Navegação principal
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', function() {
            const sectionId = this.getAttribute('data-section');
            showSection(sectionId);
        });
    });

    // Tópicos
    document.querySelectorAll('.topic-card').forEach(card => {
        card.addEventListener('click', function() {
            const topicId = this.getAttribute('data-topic');
            openTopic(topicId);
        });
    });

    // Botão de nova conversa
    document.getElementById('newPostBtn').addEventListener('click', createNewPost);

    // Funcionalidade de busca
    const searchInput = document.querySelector('.search-input');
    const searchBtn = document.querySelector('.search-btn');
    
    searchBtn.addEventListener('click', performSearch);
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });

    // Inicializar funcionalidades do chat
    initializeChat();

    // Inicializar funcionalidades do e-book
    initializeEbook();

    // Inicializar animações de entrada
    initializeAnimations();
});

function openTopic(topicId) {
    alert(`Abrindo tópico: ${topicId}`);
    // Aqui você implementaria a navegação para o tópico específico
}

function createNewPost() {
    alert('Abrindo chat para iniciar nova conversa! 💬');
    // Aqui você implementaria o modal ou página para criar novo post
}

function performSearch() {
    const searchTerm = document.querySelector('.search-input').value.trim();
    if (searchTerm) {
        alert(`Buscando por: "${searchTerm}"`);
        // Aqui você implementaria a funcionalidade de busca
    }
}

// Funcionalidades do Chat
let currentUser = 'Você';
let messageCount = 0;

function initializeChat() {
    const chatInput = document.getElementById('chatInput');
    const sendButton = document.getElementById('sendButton');
    
    // Send message on button click
    sendButton.addEventListener('click', sendMessage);
    
    // Send message on Enter key
    chatInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // Enable/disable send button based on input
    chatInput.addEventListener('input', function() {
        sendButton.disabled = this.value.trim() === '';
    });
    
    // Initial state
    sendButton.disabled = true;
}

function getCurrentTime() {
    const now = new Date();
    return now.getHours().toString().padStart(2, '0') + ':' + 
           now.getMinutes().toString().padStart(2, '0');
}

function addMessage(text, isMyMessage = true, author = 'Você') {
    const chatMessages = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isMyMessage ? 'my-message' : 'other-message'}`;
    
    const avatarInitials = author.split(' ').map(word => word[0]).join('').toUpperCase().substring(0, 2);
    
    messageDiv.innerHTML = `
        <div class="message-avatar">${avatarInitials}</div>
        <div class="message-content">
            <div class="message-header">
                <span class="message-author">${author}</span>
                <span class="message-time">${getCurrentTime()}</span>
            </div>
            <div class="message-text">${text}</div>
        </div>
    `;
    
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    messageCount++;
}

function sendMessage() {
    const chatInput = document.getElementById('chatInput');
    const message = chatInput.value.trim();
    
    if (message) {
        addMessage(message, true, currentUser);
        chatInput.value = '';
        
        // Simulate typing indicator
        showTypingIndicator();
        
        // Simulate response after 2-3 seconds
        setTimeout(() => {
            hideTypingIndicator();
            simulateResponse(message);
        }, Math.random() * 2000 + 1000);
    }
}

function simulateResponse(originalMessage) {
    const responses = [
        "Interessante! Pode me dar mais detalhes sobre isso?",
        "Já passei por algo similar. Vou te ajudar!",
        "Boa pergunta! Alguém mais pode contribuir?",
        "Obrigado por compartilhar essa informação!",
        "Vou verificar isso e te retorno em breve.",
        "Excelente ponto! Concordo totalmente.",
        "Isso pode ser resolvido nas configurações do sistema."
    ];
    
    const authors = ['Admin Suporte', 'Tech Helper', 'SuperHelper', 'Community Star'];
    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    const randomAuthor = authors[Math.floor(Math.random() * authors.length)];
    
    addMessage(randomResponse, false, randomAuthor);
}

function showTypingIndicator() {
    document.getElementById('typingIndicator').style.display = 'flex';
}

function hideTypingIndicator() {
    document.getElementById('typingIndicator').style.display = 'none';
}

// Funcionalidades do E-book
let moduleProgress = {
    1: { currentStep: 1, completed: false },
    2: { currentStep: 1, completed: false },
    3: { currentStep: 1, completed: false },
    4: { currentStep: 1, completed: false },
    5: { currentStep: 1, completed: false }
};

let completedModules = 0;

function initializeEbook() {
    // Navegação entre módulos
    document.querySelectorAll('.module-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const moduleNumber = this.getAttribute('data-module');
            showModule(moduleNumber);
        });
    });

    // Botões de próximo passo
    document.querySelectorAll('.next-step-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const step = parseInt(this.getAttribute('data-step'));
            const moduleNumber = parseInt(this.getAttribute('data-module'));
            nextStep(step, moduleNumber);
        });
    });

    // Botões de conclusão de módulo
    document.querySelectorAll('.complete-module-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const moduleNumber = parseInt(this.getAttribute('data-module'));
            completeModule(moduleNumber);
        });
    });

    // Botão de download do certificado
    document.getElementById('downloadCertificate').addEventListener('click', downloadCertificate);

    // Funcionalidade dos checkboxes
    const checkboxes = document.querySelectorAll('.checklist input[type="checkbox"]');
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            if (this.checked) {
                this.parentElement.style.background = 'rgba(39, 174, 96, 0.1)';
                this.parentElement.style.color = '#27ae60';
            } else {
                this.parentElement.style.background = '';
                this.parentElement.style.color = '';
            }
        });
    });
}

function showModule(moduleNumber) {
    // Update navigation
    document.querySelectorAll('.module-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    // Show module content
    document.querySelectorAll('.module-content').forEach(content => content.classList.remove('active'));
    document.getElementById(`module${moduleNumber}`).classList.add('active');
    
    // Update progress display
    updateProgressDisplay(moduleNumber);
}

function nextStep(currentStep, moduleNumber = 1) {
    const module = document.getElementById(`module${moduleNumber}`);
    const currentStepElement = module.querySelector(`[data-step="${currentStep}"]`);
    const nextStepElement = module.querySelector(`[data-step="${currentStep + 1}"]`);
    
    if (nextStepElement) {
        currentStepElement.style.display = 'none';
        nextStepElement.style.display = 'block';
        
        moduleProgress[moduleNumber].currentStep = currentStep + 1;
        updateProgressDisplay(moduleNumber);
        
        // Scroll to top of new step
        nextStepElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

function updateProgressDisplay(moduleNumber) {
    const progress = moduleProgress[moduleNumber];
    const totalSteps = 3;
    const progressPercentage = ((progress.currentStep - 1) / totalSteps) * 100;
    
    const module = document.getElementById(`module${moduleNumber}`);
    const progressFill = module.querySelector('.progress-fill');
    const progressText = module.querySelector('.progress-text');
    
    progressFill.style.width = `${progressPercentage}%`;
    progressText.textContent = `${Math.round(progressPercentage)}% Concluído`;
}

function completeModule(moduleNumber) {
    moduleProgress[moduleNumber].completed = true;
    completedModules++;
    
    // Update progress to 100%
    const module = document.getElementById(`module${moduleNumber}`);
    const progressFill = module.querySelector('.progress-fill');
    const progressText = module.querySelector('.progress-text');
    
    progressFill.style.width = '100%';
    progressText.textContent = '100% Concluído';
    progressText.style.color = '#27ae60';
    
    // Show completion message
    alert(`🎉 Parabéns! Você concluiu o Módulo ${moduleNumber}!`);
    
    // Check if all modules are completed
    if (completedModules === 5) {
        setTimeout(() => {
            showCertificate();
        }, 1000);
    } else {
        // Suggest next module
        const nextModule = moduleNumber < 5 ? moduleNumber + 1 : null;
        if (nextModule) {
            setTimeout(() => {
                if (confirm(`Deseja continuar para o Módulo ${nextModule}?`)) {
                    showModule(nextModule);
                }
            }, 1500);
        }
    }
}

function showCertificate() {
    // Hide all module content
    document.querySelectorAll('.module-content').forEach(content => content.classList.remove('active'));
    
    // Show certificate
    const certificate = document.getElementById('certificate');
    certificate.style.display = 'block';
    
    // Set completion date
    const today = new Date();
    const dateString = today.toLocaleDateString('pt-BR');
    document.getElementById('completionDate').textContent = dateString;
    
    // Scroll to certificate
    certificate.scrollIntoView({ behavior: 'smooth' });
    
    // Show congratulations
    setTimeout(() => {
        alert('🏆 PARABÉNS! Você concluiu todos os módulos e ganhou seu certificado!');
    }, 500);
}

function downloadCertificate() {
    // Simulate certificate download
    alert('📥 Certificado baixado com sucesso!\n\nO arquivo foi salvo como "Certificado_Jovem_Aprendiz.pdf"');
    
    // In a real application, this would generate and download a PDF
    // For demo purposes, we'll just show the success message
}

// Animação de entrada
function initializeAnimations() {
    const cards = document.querySelectorAll('.topic-card, .discussion-item, .sidebar-card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        setTimeout(() => {
            card.style.transition = 'all 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
}