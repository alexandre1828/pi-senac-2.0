// auth.js - Sistema de Autenticação HELP ADM

class SistemaAutenticacao {
    constructor() {
        this.dadosUsuario = {
            nome: 'Usuário',
            email: '',
            dataRegistro: new Date(),
            ultimoAcesso: new Date(),
            estaLogado: false
        };

        // Base de usuários cadastrados (simulada)
        this.usuariosCadastrados = JSON.parse(localStorage.getItem('helpadm_usuarios')) || [
            'admin@helpadm.com',
            'usuario@helpadm.com'
        ];

        this.inicializar();
    }

    inicializar() {
        this.verificarLoginAnterior();
        this.configurarEventListeners();
    }

    verificarLoginAnterior() {
        const usuarioSalvo = localStorage.getItem('helpadm_usuario_logado');
        if (usuarioSalvo) {
            this.dadosUsuario = { ...this.dadosUsuario, ...JSON.parse(usuarioSalvo), estaLogado: true };
            this.ocultarAutenticacao();
        } else {
            this.mostrarAutenticacao();
        }
    }

    mostrarAutenticacao() {
        // Criar overlay de autenticação se não existir
        if (!document.getElementById('authOverlay')) {
            const authHTML = `
                <div class="auth-overlay" id="authOverlay">
                    <main class="container-autenticacao">
                        <!-- Tela de Login -->
                        <section id="secaoLogin" class="secao-formulario">
                            <header class="cabecalho-marca">
                                <div class="logo-marca">🔐</div>
                                <h1 class="titulo-marca">HELP ADM</h1>
                                <p class="subtitulo-marca">Acesse sua conta para continuar</p>
                            </header>
                            
                            <form id="formularioLogin">
                                <div class="grupo-formulario">
                                    <label for="emailLogin" class="rotulo-formulario">Email</label>
                                    <input type="email" id="emailLogin" class="entrada-formulario" required>
                                    <div class="mensagem-erro" id="erroEmailLogin"></div>
                                </div>
                                
                                <div class="grupo-formulario">
                                    <label for="senhaLogin" class="rotulo-formulario">Senha</label>
                                    <input type="password" id="senhaLogin" class="entrada-formulario" required>
                                    <div class="mensagem-erro" id="erroSenhaLogin"></div>
                                </div>
                                
                                <div class="grupo-caixa-selecao">
                                    <input type="checkbox" id="lembrarDeMim" class="caixa-selecao">
                                    <label for="lembrarDeMim" class="rotulo-caixa-selecao">Lembrar de mim</label>
                                </div>
                                
                                <button type="submit" class="botao botao-principal" id="botaoLogin">
                                    Entrar
                                </button>
                            </form>
                            
                            <div class="texto-centralizado">
                                <a href="#" class="link" onclick="auth.mostrarEsqueciSenha()">Esqueci minha senha</a>
                            </div>
                            
                            <div class="divisor">
                                <span>ou</span>
                            </div>
                            
                            <button type="button" class="botao botao-secundario" onclick="auth.mostrarRegistro()">
                                Criar nova conta
                            </button>
                        </section>

                        <!-- Tela de Cadastro -->
                        <section id="secaoRegistro" class="secao-formulario oculto">
                            <header class="cabecalho-marca">
                                <div class="logo-marca">📝</div>
                                <h1 class="titulo-marca">Criar Conta</h1>
                                <p class="subtitulo-marca">Junte-se à comunidade HELP ADM</p>
                            </header>
                            
                            <form id="formularioRegistro">
                                <div class="grupo-formulario">
                                    <label for="nomeRegistro" class="rotulo-formulario">Nome completo</label>
                                    <input type="text" id="nomeRegistro" class="entrada-formulario" required>
                                    <div class="mensagem-erro" id="erroNomeRegistro"></div>
                                </div>
                                
                                <div class="grupo-formulario">
                                    <label for="emailRegistro" class="rotulo-formulario">Email</label>
                                    <input type="email" id="emailRegistro" class="entrada-formulario" required>
                                    <div class="mensagem-erro" id="erroEmailRegistro"></div>
                                </div>
                                
                                <div class="grupo-formulario">
                                    <label for="senhaRegistro" class="rotulo-formulario">Senha</label>
                                    <input type="password" id="senhaRegistro" class="entrada-formulario" required>
                                    <div class="forca-senha" id="forcaSenha">
                                        <div class="barra-forca">
                                            <div class="preenchimento-forca" id="preenchimentoForca"></div>
                                        </div>
                                        <div class="texto-forca" id="textoForca"></div>
                                    </div>
                                    <div class="mensagem-erro" id="erroSenhaRegistro"></div>
                                </div>
                                
                                <div class="grupo-formulario">
                                    <label for="confirmarSenha" class="rotulo-formulario">Confirmar senha</label>
                                    <input type="password" id="confirmarSenha" class="entrada-formulario" required>
                                    <div class="mensagem-erro" id="erroConfirmarSenha"></div>
                                </div>
                                
                                <div class="grupo-caixa-selecao">
                                    <input type="checkbox" id="concordarTermos" class="caixa-selecao" required>
                                    <label for="concordarTermos" class="rotulo-caixa-selecao">
                                        Concordo com os <a href="#" class="link">Termos de Uso</a> e <a href="#" class="link">Política de Privacidade</a>
                                    </label>
                                </div>
                                
                                <button type="submit" class="botao botao-principal" id="botaoRegistro">
                                    Criar conta
                                </button>
                            </form>
                            
                            <div class="texto-centralizado" style="margin-top: 24px;">
                                <span style="color: #718096;">Já tem uma conta? </span>
                                <a href="#" class="link" onclick="auth.mostrarLogin()">Fazer login</a>
                            </div>
                        </section>

                        <!-- Tela de Recuperação de Senha -->
                        <section id="secaoEsqueciSenha" class="secao-formulario oculto">
                            <button class="botao-voltar" onclick="auth.mostrarLogin()">Voltar</button>
                            
                            <header class="cabecalho-marca">
                                <div class="logo-marca">🔑</div>
                                <h1 class="titulo-marca">Recuperar Senha</h1>
                                <p class="subtitulo-marca">Digite seu email para receber as instruções</p>
                            </header>
                            
                            <form id="formularioEsqueciSenha" class="formulario-esqueci-senha">
                                <div class="grupo-formulario">
                                    <label for="emailEsqueci" class="rotulo-formulario">Email</label>
                                    <input type="email" id="emailEsqueci" class="entrada-formulario" required>
                                    <div class="mensagem-erro" id="erroEmailEsqueci"></div>
                                </div>
                                
                                <button type="submit" class="botao botao-principal" id="botaoEsqueci">
                                    Enviar instruções
                                </button>
                            </form>
                        </section>

                        <!-- Tela de Acesso Bloqueado -->
                        <section id="secaoAcessoBloqueado" class="secao-formulario oculto">
                            <header class="cabecalho-marca">
                                <div class="logo-marca">🚫</div>
                                <h1 class="titulo-marca">Acesso Bloqueado</h1>
                                <p class="subtitulo-marca">Usuário não cadastrado no sistema</p>
                            </header>
                            
                            <div class="alerta-erro">
                                Este email não está cadastrado em nosso sistema. Por favor, crie uma conta para acessar.
                            </div>
                            
                            <div class="texto-centralizado">
                                <p style="color: #718096; margin-bottom: 24px;">
                                    Você precisa se cadastrar antes de acessar o sistema.
                                </p>
                                
                                <button type="button" class="botao botao-principal" onclick="auth.mostrarRegistro()">
                                    Criar Nova Conta
                                </button>
                                
                                <button type="button" class="botao botao-secundario" onclick="auth.mostrarLogin()">
                                    Tentar Outro Email
                                </button>
                            </div>
                        </section>
                    </main>
                </div>
            `;
            document.body.insertAdjacentHTML('afterbegin', authHTML);
        }
        
        document.getElementById('authOverlay').style.display = 'flex';
        this.mostrarLogin();
    }

    ocultarAutenticacao() {
        const authOverlay = document.getElementById('authOverlay');
        if (authOverlay) {
            authOverlay.style.display = 'none';
        }
        
        // Atualizar interface do usuário logado
        this.atualizarInterfaceUsuario();
    }

    atualizarInterfaceUsuario() {
        const userMenu = document.querySelector('.user-menu');
        if (userMenu && this.dadosUsuario.estaLogado) {
            userMenu.innerHTML = `👤 ${this.dadosUsuario.nome.split(' ')[0]}`;
            
            // Adicionar funcionalidade de logout ao menu
            userMenu.onclick = () => this.mostrarMenuUsuario();
        }
    }

    mostrarMenuUsuario() {
        const menuHTML = `
            <div style="position: absolute; top: 100%; right: 0; background: white; border-radius: 12px; padding: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); min-width: 200px; z-index: 1000;">
                <div style="padding: 10px; border-bottom: 1px solid #eee;">
                    <strong>${this.dadosUsuario.nome}</strong>
                    <div style="font-size: 12px; color: #666;">${this.dadosUsuario.email}</div>
                </div>
                <button onclick="auth.sair()" style="width: 100%; padding: 10px; background: #ff6b35; color: white; border: none; border-radius: 8px; cursor: pointer; margin-top: 10px;">
                    Sair
                </button>
            </div>
        `;
        
        // Implementar lógica para mostrar menu dropdown
        alert(`Bem-vindo, ${this.dadosUsuario.nome}!\n\nEmail: ${this.dadosUsuario.email}\n\nUse o botão "Sair" para deslogar.`);
    }

    // Métodos de navegação
    mostrarLogin() {
        this.ocultarTodasSecoes();
        document.getElementById('secaoLogin').classList.remove('oculto');
        this.limparFormularios();
    }

    mostrarRegistro() {
        this.ocultarTodasSecoes();
        document.getElementById('secaoRegistro').classList.remove('oculto');
    }

    mostrarEsqueciSenha() {
        this.ocultarTodasSecoes();
        document.getElementById('secaoEsqueciSenha').classList.remove('oculto');
    }

    mostrarAcessoBloqueado() {
        this.ocultarTodasSecoes();
        document.getElementById('secaoAcessoBloqueado').classList.remove('oculto');
    }

    ocultarTodasSecoes() {
        const secoes = ['secaoLogin', 'secaoRegistro', 'secaoEsqueciSenha', 'secaoAcessoBloqueado'];
        secoes.forEach(id => {
            const elemento = document.getElementById(id);
            if (elemento) elemento.classList.add('oculto');
        });
    }

    // Métodos de validação
    emailValido(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    usuarioCadastrado(email) {
        return this.usuariosCadastrados.includes(email.toLowerCase());
    }

    obterForcaSenha(senha) {
        let pontuacao = 0;
        if (senha.length >= 8) pontuacao++;
        if (/[a-z]/.test(senha)) pontuacao++;
        if (/[A-Z]/.test(senha)) pontuacao++;
        if (/[0-9]/.test(senha)) pontuacao++;
        if (/[^A-Za-z0-9]/.test(senha)) pontuacao++;
        
        const forcas = ['Muito fraca', 'Fraca', 'Regular', 'Boa', 'Muito forte'];
        const cores = ['#e53e3e', '#fd9801', '#fbb042', '#48bb78', '#38a169'];
        
        return {
            pontuacao: pontuacao,
            texto: forcas[pontuacao - 1] || 'Muito fraca',
            cor: cores[pontuacao - 1] || '#e53e3e',
            porcentagem: (pontuacao / 5) * 100
        };
    }

    // Métodos de UI
    mostrarErro(idEntrada, mensagem) {
        const entrada = document.getElementById(idEntrada);
        const elementoErro = document.getElementById('erro' + idEntrada.charAt(0).toUpperCase() + idEntrada.slice(1));
        
        if (entrada && elementoErro) {
            entrada.classList.add('erro');
            elementoErro.textContent = mensagem;
            elementoErro.style.display = 'block';
        }
    }

    limparErros() {
        const elementosErro = document.querySelectorAll('.mensagem-erro');
        elementosErro.forEach(el => {
            el.style.display = 'none';
            el.textContent = '';
        });
        
        const entradas = document.querySelectorAll('.entrada-formulario');
        entradas.forEach(entrada => entrada.classList.remove('erro'));
    }

    limparFormularios() {
        const formularios = ['formularioLogin', 'formularioRegistro', 'formularioEsqueciSenha'];
        formularios.forEach(id => {
            const form = document.getElementById(id);
            if (form) form.reset();
        });
        this.limparErros();
    }

    definirBotaoCarregando(idBotao, carregando) {
        const botao = document.getElementById(idBotao);
        if (botao) {
            if (carregando) {
                botao.classList.add('botao-carregando');
                botao.disabled = true;
                const textoOriginal = botao.textContent;
                botao.setAttribute('data-texto-original', textoOriginal);
                botao.textContent = '';
            } else {
                botao.classList.remove('botao-carregando');
                botao.disabled = false;
                botao.textContent = botao.getAttribute('data-texto-original') || botao.textContent;
            }
        }
    }

    // Métodos de autenticação
    async fazerLogin(email, senha, lembrarDeMim) {
        // Simular requisição de API
        return new Promise((resolve) => {
            setTimeout(() => {
                if (this.usuarioCadastrado(email)) {
                    this.dadosUsuario = {
                        ...this.dadosUsuario,
                        email: email,
                        nome: email.split('@')[0],
                        ultimoAcesso: new Date(),
                        estaLogado: true
                    };

                    if (lembrarDeMim) {
                        localStorage.setItem('helpadm_usuario_logado', JSON.stringify(this.dadosUsuario));
                    }

                    // Salvar lista atualizada de usuários
                    localStorage.setItem('helpadm_usuarios', JSON.stringify(this.usuariosCadastrados));
                    
                    resolve({ success: true });
                } else {
                    resolve({ success: false, error: 'Usuário não cadastrado' });
                }
            }, 1500);
        });
    }

    async criarConta(nome, email, senha) {
        return new Promise((resolve) => {
            setTimeout(() => {
                this.usuariosCadastrados.push(email.toLowerCase());
                
                this.dadosUsuario = {
                    nome: nome,
                    email: email,
                    dataRegistro: new Date(),
                    ultimoAcesso: new Date(),
                    estaLogado: true
                };

                localStorage.setItem('helpadm_usuario_logado', JSON.stringify(this.dadosUsuario));
                localStorage.setItem('helpadm_usuarios', JSON.stringify(this.usuariosCadastrados));
                
                resolve({ success: true });
            }, 2000);
        });
    }

    sair() {
        this.dadosUsuario.estaLogado = false;
        localStorage.removeItem('helpadm_usuario_logado');
        this.mostrarAutenticacao();
        
        // Recarregar a página para resetar o estado
        setTimeout(() => location.reload(), 500);
    }

    configurarEventListeners() {
        // Configurar event listeners quando o DOM estiver pronto
        document.addEventListener('DOMContentLoaded', () => {
            // Login form
            const formularioLogin = document.getElementById('formularioLogin');
            if (formularioLogin) {
                formularioLogin.addEventListener('submit', (e) => {
                    e.preventDefault();
                    this.limparErros();
                    
                    const email = document.getElementById('emailLogin').value;
                    const senha = document.getElementById('senhaLogin').value;
                    const lembrarDeMim = document.getElementById('lembrarDeMim').checked;
                    
                    let temErro = false;
                    
                    if (!email) {
                        this.mostrarErro('emailLogin', 'Email é obrigatório');
                        temErro = true;
                    } else if (!this.emailValido(email)) {
                        this.mostrarErro('emailLogin', 'Email inválido');
                        temErro = true;
                    }
                    
                    if (!senha) {
                        this.mostrarErro('senhaLogin', 'Senha é obrigatória');
                        temErro = true;
                    }
                    
                    if (!temErro) {
                        this.definirBotaoCarregando('botaoLogin', true);
                        
                        this.fazerLogin(email, senha, lembrarDeMim).then(resultado => {
                            this.definirBotaoCarregando('botaoLogin', false);
                            
                            if (resultado.success) {
                                this.ocultarAutenticacao();
                            } else {
                                this.mostrarAcessoBloqueado();
                            }
                        });
                    }
                });
            }

            // Register form
            const formularioRegistro = document.getElementById('formularioRegistro');
            if (formularioRegistro) {
                formularioRegistro.addEventListener('submit', (e) => {
                    e.preventDefault();
                    this.limparErros();
                    
                    const nome = document.getElementById('nomeRegistro').value;
                    const email = document.getElementById('emailRegistro').value;
                    const senha = document.getElementById('senhaRegistro').value;
                    const confirmarSenha = document.getElementById('confirmarSenha').value;
                    const concordarTermos = document.getElementById('concordarTermos').checked;
                    
                    let temErro = false;
                    
                    if (!nome || nome.length < 2) {
                        this.mostrarErro('nomeRegistro', 'Nome deve ter pelo menos 2 caracteres');
                        temErro = true;
                    }
                    
                    if (!email) {
                        this.mostrarErro('emailRegistro', 'Email é obrigatório');
                        temErro = true;
                    } else if (!this.emailValido(email)) {
                        this.mostrarErro('emailRegistro', 'Email inválido');
                        temErro = true;
                    }
                    
                    if (!senha) {
                        this.mostrarErro('senhaRegistro', 'Senha é obrigatória');
                        temErro = true;
                    } else if (senha.length < 6) {
                        this.mostrarErro('senhaRegistro', 'Senha deve ter pelo menos 6 caracteres');
                        temErro = true;
                    }
                    
                    if (senha !== confirmarSenha) {
                        this.mostrarErro('confirmarSenha', 'Senhas não coincidem');
                        temErro = true;
                    }
                    
                    if (!concordarTermos) {
                        this.mostrarErro('concordarTermos', 'Você deve concordar com os termos');
                        temErro = true;
                    }
                    
                    if (!temErro) {
                        this.definirBotaoCarregando('botaoRegistro', true);
                        
                        this.criarConta(nome, email, senha).then(() => {
                            this.definirBotaoCarregando('botaoRegistro', false);
                            this.ocultarAutenticacao();
                        });
                    }
                });

                // Força da senha
                const senhaRegistro = document.getElementById('senhaRegistro');
                if (senhaRegistro) {
                    senhaRegistro.addEventListener('input', () => {
                        const senha = senhaRegistro.value;
                        const elementoForca = document.getElementById('forcaSenha');
                        
                        if (senha.length > 0 && elementoForca) {
                            elementoForca.style.display = 'block';
                            const forca = this.obterForcaSenha(senha);
                            
                            document.getElementById('preenchimentoForca').style.width = forca.porcentagem + '%';
                            document.getElementById('preenchimentoForca').style.background = forca.cor;
                            document.getElementById('textoForca').textContent = forca.texto;
                            document.getElementById('textoForca').style.color = forca.cor;
                        } else if (elementoForca) {
                            elementoForca.style.display = 'none';
                        }
                    });
                }
            }

            // Forgot password form
            const formularioEsqueciSenha = document.getElementById('formularioEsqueciSenha');
            if (formularioEsqueciSenha) {
                formularioEsqueciSenha.addEventListener('submit', (e) => {
                    e.preventDefault();
                    this.limparErros();
                    
                    const email = document.getElementById('emailEsqueci').value;
                    
                    if (!email) {
                        this.mostrarErro('emailEsqueci', 'Email é obrigatório');
                        return;
                    }
                    
                    if (!this.emailValido(email)) {
                        this.mostrarErro('emailEsqueci', 'Email inválido');
                        return;
                    }

                    if (!this.usuarioCadastrado(email)) {
                        this.mostrarErro('emailEsqueci', 'Email não cadastrado no sistema');
                        return;
                    }
                    
                    this.definirBotaoCarregando('botaoEsqueci', true);
                    
                    setTimeout(() => {
                        this.definirBotaoCarregando('botaoEsqueci', false);
                        const botao = document.getElementById('botaoEsqueci');
                        botao.textContent = 'Instruções enviadas!';
                        botao.style.background = '#48bb78';
                        
                        setTimeout(() => {
                            botao.textContent = 'Enviar instruções';
                            botao.style.background = '';
                            this.mostrarLogin();
                        }, 2000);
                    }, 1500);
                });
            }
        });
    }

// auth.js - Substitua o método sair() por esta versão completa

sair() {
    if (confirm('🚪 Sair da Conta\n\nTem certeza que deseja sair da sua conta?\n\nVocê precisará fazer login novamente para acessar o HELP ADM.')) {
        this.realizarLogout();
    }
}

realizarLogout() {
    // Limpar dados do usuário
    this.dadosUsuario = {
        nome: 'Usuário',
        email: '',
        dataRegistro: new Date(),
        ultimoAcesso: new Date(),
        estaLogado: false
    };
    
    // Remover do localStorage
    localStorage.removeItem('helpadm_usuario_logado');
    
    // Remover menu dropdown se estiver aberto
    this.removerMenuUsuario();
    
    // Mostrar overlay de saída
    this.mostrarOverlaySaida();
    
    // Após 2 segundos, mostrar tela de login
    setTimeout(() => {
        this.ocultarOverlaySaida();
        this.mostrarTelaLoginAposLogout();
    }, 2000);
}

mostrarOverlaySaida() {
    const overlay = document.createElement('div');
    overlay.id = 'logoutOverlay';
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10001;
        color: white;
        font-family: 'Inter', sans-serif;
    `;
    
    overlay.innerHTML = `
        <div style="text-align: center; padding: 40px; max-width: 400px;">
            <div style="font-size: 4rem; margin-bottom: 20px;">👋</div>
            <h2 style="font-size: 2rem; margin-bottom: 16px; font-weight: 700;">Até logo!</h2>
            <p style="font-size: 1.1rem; opacity: 0.9; margin-bottom: 10px;">Obrigado por usar o HELP ADM</p>
            <p style="font-size: 0.9rem; opacity: 0.7;">Redirecionando para o login...</p>
            <div style="margin-top: 30px;">
                <div style="width: 40px; height: 40px; border: 3px solid rgba(255,255,255,0.3); border-top: 3px solid white; border-radius: 50%; animation: girar 1s linear infinite; margin: 0 auto;"></div>
            </div>
        </div>
    `;
    
    document.body.appendChild(overlay);
}

ocultarOverlaySaida() {
    const overlay = document.getElementById('logoutOverlay');
    if (overlay) {
        overlay.remove();
    }
}

mostrarTelaLoginAposLogout() {
    // Esconder a interface principal
    this.esconderInterfacePrincipal();
    
    // Mostrar tela de autenticação
    this.mostrarAutenticacao();
    
    // Mostrar mensagem de logout bem-sucedido
    this.mostrarMensagemLogoutSucesso();
}

esconderInterfacePrincipal() {
    const mainContainer = document.querySelector('.main-container');
    if (mainContainer) {
        mainContainer.style.display = 'none';
    }
    
    // Também esconder qualquer overlay de autenticação existente
    const authOverlay = document.getElementById('authOverlay');
    if (authOverlay) {
        authOverlay.style.display = 'none';
    }
}

mostrarMensagemLogoutSucesso() {
    // Criar uma mensagem temporária na tela de login
    const mensagem = document.createElement('div');
    mensagem.id = 'mensagemLogout';
    mensagem.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: linear-gradient(135deg, #48bb78, #38a169);
        color: white;
        padding: 16px 24px;
        border-radius: 12px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        z-index: 10002;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 10px;
        animation: slideInDown 0.5s ease-out;
    `;
    
    mensagem.innerHTML = `
        <span>✅</span>
        <span>Logout realizado com sucesso! Faça login novamente para continuar.</span>
    `;
    
    document.body.appendChild(mensagem);
    
    // Remover a mensagem após 5 segundos
    setTimeout(() => {
        if (mensagem.parentNode) {
            mensagem.style.animation = 'slideOutUp 0.5s ease-in forwards';
            setTimeout(() => {
                if (mensagem.parentNode) {
                    mensagem.remove();
                }
            }, 500);
        }
    }, 5000);
}

// Adicione também estes estilos de animação
adicionarEstilosAnimacao() {
    if (!document.querySelector('#authAnimations')) {
        const style = document.createElement('style');
        style.id = 'authAnimations';
        style.textContent = `
            @keyframes girar {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            
            @keyframes slideInDown {
                from {
                    opacity: 0;
                    transform: translateX(-50%) translateY(-20px);
                }
                to {
                    opacity: 1;
                    transform: translateX(-50%) translateY(0);
                }
            }
            
            @keyframes slideOutUp {
                from {
                    opacity: 1;
                    transform: translateX(-50%) translateY(0);
                }
                to {
                    opacity: 0;
                    transform: translateX(-50%) translateY(-20px);
                }
            }
            
            .logout-success-message {
                animation: slideInDown 0.5s ease-out;
            }
        `;
        document.head.appendChild(style);
    }
}

// Atualize o método inicializar() para incluir os estilos de animação
inicializar() {
    this.adicionarEstilosAnimacao();
    this.verificarLoginAnterior();
    this.configurarEventListeners();
}

}

// Inicializar sistema de autenticação
const auth = new SistemaAutenticacao();